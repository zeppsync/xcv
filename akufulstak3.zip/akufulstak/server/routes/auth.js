const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const authMiddleware = require('../middleware/auth');
const router = express.Router();
const patientModel = new User();

router.post('/register', async (req, res) => {
    try {
        const patientData = req.body;
        await patientModel.create(patientData);
        res.status(201).json({ message: 'Pendaftaran pasien berhasil!' });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({ message: 'Email sudah terdaftar' });
        }
        res.status(500).json({ message: 'Server error' });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const isValid = await patientModel.comparePassword(email, password);
        
        if (!isValid) {
            return res.status(400).json({ message: 'Email/password salah' });
        }

        const patient = await patientModel.findByEmail(email);
        const token = jwt.sign(
            { id: patient._id, email: patient.email },
            process.env.JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({ 
            message: 'Login berhasil',
            token,
            patient: {
                id: patient._id,
                name: patient.name,
                email: patient.email
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/patients', authMiddleware, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        
        const patients = await patientModel.getAllPatients(page, limit);
        const total = await patientModel.getPatientsCount();
        
        res.json({
            patients,
            pagination: {
                current: page,
                pages: Math.ceil(total / limit),
                total
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/patients/:id', authMiddleware, async (req, res) => {
    try {
        const patient = await patientModel.findById(req.params.id);
        if (!patient) {
            return res.status(404).json({ message: 'Pasien tidak ditemukan' });
        }
        res.json(patient);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.put('/patients/:id', authMiddleware, async (req, res) => {
    try {
        const result = await patientModel.update(req.params.id, req.body);
        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Pasien tidak ditemukan' });
        }
        res.json({ message: 'Data pasien berhasil diupdate!' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.delete('/patients/:id', authMiddleware, async (req, res) => {
    try {
        const result = await patientModel.delete(req.params.id);
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: 'Pasien tidak ditemukan' });
        }
        res.json({ message: 'Pasien berhasil dihapus!' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

router.get('/me', authMiddleware, async (req, res) => {
    try {
        const patient = await patientModel.findByEmail(req.user.email);
        res.json({
            patient: {
                id: patient._id,
                name: patient.name,
                email: patient.email,
                phone: patient.phone,
                description: patient.description
            }
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;