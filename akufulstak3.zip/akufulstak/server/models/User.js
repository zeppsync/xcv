const { MongoClient } = require('mongodb');
const bcrypt = require('bcryptjs');

class User {
    constructor() {
        this.client = new MongoClient('mongodb+srv://ZepysK:TenkaCantiq123@cluster0.fntfzii.mongodb.net/?appName=Cluster0');
        this.dbName = 'authdb';
        this.collectionName = 'users';
    }

    async connect() {
        if (this.db) return;
        await this.client.connect();
        this.db = this.client.db(this.dbName);
        this.collection = this.db.collection(this.collectionName);
        await this.collection.createIndex({ email: 1 }, { unique: true });
        console.log(`Connected to ${this.dbName}.${this.collectionName}`);
    }

    async create(patientData) {
        await this.connect();
        const hashedPassword = await bcrypt.hash(patientData.password, 12);
        const patient = {
            name: patientData.name,
            email: patientData.email,
            password: hashedPassword,
            phone: patientData.phone || '',
            address: patientData.address || '',
            description: patientData.description || '',
            gender: patientData.gender || '',
            dateOfBirth: patientData.dateOfBirth || '',
            createdAt: new Date()
        };
        const result = await this.collection.insertOne(patient);
        return result.insertedId;
    }

    async findByEmail(email) {
        await this.connect();
        return this.collection.findOne({ email });
    }

    async findById(id) {
        await this.connect();
        return this.collection.findOne({ _id: new this.client.db().ObjectId(id) });
    }

    async getAllPatients(page = 1, limit = 10) {
        await this.connect();
        const skip = (page - 1) * limit;
        return this.collection.find({}).skip(skip).limit(limit).toArray();
    }

    async getPatientsCount() {
        await this.connect();
        return this.collection.countDocuments();
    }

    async update(id, updateData) {
        await this.connect();
        updateData.updatedAt = new Date();
        if (updateData.password) {
            updateData.password = await bcrypt.hash(updateData.password, 12);
        }
        
        const result = await this.collection.updateOne(
            { _id: new this.client.db().ObjectId(id) },
            { $set: updateData }
        );
        return result;
    }

    async delete(id) {
        await this.connect();
        const result = await this.collection.deleteOne({ 
            _id: new this.client.db().ObjectId(id) 
        });
        return result;
    }

    async comparePassword(email, password) {
        const patient = await this.findByEmail(email);
        if (!patient) return false;
        return bcrypt.compare(password, patient.password);
    }
}

module.exports = User;