const API_BASE = '/api/auth';
let currentPatients = [];
let currentPage = 1;
let patientsPerPage = 10;

const showAlert = (message, type = 'success') => {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${message}
    `;
    document.querySelector('.main-content')?.insertBefore(alert, document.querySelector('.main-content').firstChild);
    setTimeout(() => alert.remove(), 4000);
};

const getToken = () => localStorage.getItem('token');
const saveToken = (token) => localStorage.setItem('token', token);
const removeToken = () => localStorage.removeItem('token');

const checkAuth = async () => {
    const token = getToken();
    if (!token) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
};

const logout = () => {
    removeToken();
    window.location.href = 'login.html';
};

const loadDashboard = async () => {
    if (!await checkAuth()) return;
    
    try {
        const response = await fetch(`${API_BASE}/me`, {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        const data = await response.json();
        
        document.getElementById('userName').textContent = data.patient.name;
        document.getElementById('welcomeName').textContent = data.patient.name;
        
        const patientsRes = await fetch(`${API_BASE}/patients`, {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        const patientsData = await patientsRes.json();
        document.getElementById('totalPatients').textContent = patientsData.pagination.total;
        
    } catch (error) {
        removeToken();
        window.location.href = 'login.html';
    }
};

const loadPatients = async (page = 1) => {
    if (!await checkAuth()) return;
    
    try {
        const response = await fetch(`${API_BASE}/patients?page=${page}&limit=${patientsPerPage}`, {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        const data = await response.json();
        
        currentPatients = data.patients;
        currentPage = page;
        renderPatientsTable(data.patients);
        renderPagination(data.pagination);
        updateUserName();
        
    } catch (error) {
        showAlert('Gagal memuat data pasien', 'error');
    }
};

const renderPatientsTable = (patients) => {
    const tbody = document.getElementById('patientsTableBody');
    
    if (patients.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="no-data">
                    <i class="fas fa-users-slash"></i><br>
                    Belum ada data pasien
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = patients.map(patient => `
        <tr>
            <td><strong>${patient.name}</strong></td>
            <td>${patient.email}</td>
            <td>${patient.phone || '-'}</td>
            <td>${patient.description || '-'}</td>
            <td>${new Date(patient.createdAt).toLocaleDateString('id-ID')}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-small btn-outline" onclick="editPatient('${patient._id}')" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-small btn-danger" onclick="deletePatient('${patient._id}')" title="Hapus">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
};

const renderPagination = (pagination) => {
    const paginationEl = document.getElementById('pagination');
    const totalPages = pagination.pages;
    
    let html = `
        <button onclick="loadPatients(${Math.max(1, currentPage-1)})" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        html += `
            <button class="${i === currentPage ? 'active' : ''}" onclick="loadPatients(${i})">
                ${i}
            </button>
        `;
    }
    
    html += `
        <button onclick="loadPatients(${Math.min(totalPages, currentPage+1)})" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>
        <span>Hal ${currentPage} dari ${totalPages}</span>
    `;
    
    paginationEl.innerHTML = html;
};

const openModal = (mode = 'add', patient = null) => {
    const modal = document.getElementById('patientModal');
    const title = document.getElementById('modalTitle');
    
    if (mode === 'edit' && patient) {
        title.textContent = 'Edit Pasien';
        document.getElementById('patientId').value = patient._id;
        document.getElementById('patientName').value = patient.name;
        document.getElementById('patientEmail').value = patient.email;
        document.getElementById('patientPhone').value = patient.phone || '';
        document.getElementById('patientDescription').value = patient.description || '';
    } else {
        title.textContent = 'Tambah Pasien';
        document.getElementById('patientForm').reset();
        document.getElementById('patientId').value = '';
    }
    
    modal.style.display = 'block';
};

const closeModal = () => {
    document.getElementById('patientModal').style.display = 'none';
};

const savePatient = async (e) => {
    e.preventDefault();
    const patientId = document.getElementById('patientId').value;
    const patientData = {
        name: document.getElementById('patientName').value,
        email: document.getElementById('patientEmail').value,
        phone: document.getElementById('patientPhone').value,
        description: document.getElementById('patientDescription').value
    };
    
    try {
        let response;
        if (patientId) {
            response = await fetch(`${API_BASE}/patients/${patientId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${getToken()}`
                },
                body: JSON.stringify(patientData)
            });
        } else {
            response = await fetch(`${API_BASE}/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${getToken()}`
                },
                body: JSON.stringify({ ...patientData, password: '12345678' })
            });
        }
        
        if (response.ok) {
            showAlert('Data pasien berhasil disimpan!');
            closeModal();
            loadPatients(currentPage);
        } else {
            const error = await response.json();
            showAlert(error.message, 'error');
        }
    } catch (error) {
        showAlert('Terjadi kesalahan', 'error');
    }
};

const editPatient = async (id) => {
    try {
        const response = await fetch(`${API_BASE}/patients/${id}`, {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        const patient = await response.json();
        openModal('edit', patient);
    } catch (error) {
        showAlert('Gagal memuat data pasien', 'error');
    }
};

const deletePatient = async (id) => {
    if (!confirm('Yakin ingin menghapus pasien ini?')) return;
    
    try {
        const response = await fetch(`${API_BASE}/patients/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        
        if (response.ok) {
            showAlert('Pasien berhasil dihapus!');
            loadPatients(currentPage);
        } else {
            const error = await response.json();
            showAlert(error.message, 'error');
        }
    } catch (error) {
        showAlert('Gagal menghapus pasien', 'error');
    }
};

const updateUserName = async () => {
    try {
        const response = await fetch(`${API_BASE}/me`, {
            headers: { 'Authorization': `Bearer ${getToken()}` }
        });
        const data = await response.json();
        const userNameEls = document.querySelectorAll('#userName');
        userNameEls.forEach(el => el.textContent = data.patient.name);
    } catch (error) {}
};

const showAlert = (message, type = 'success') => {
    let alertContainer = document.querySelector('.alert-container');
    if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.className = 'alert-container';
        document.body.insertBefore(alertContainer, document.body.firstChild);
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${message}
        <button class="alert-close">&times;</button>
    `;
    
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        if (alert.parentNode) alert.remove();
    }, 5000);
    
    alert.querySelector('.alert-close').addEventListener('click', () => {
        alert.remove();
    });
};

const alertCSS = `
.alert {
    padding: 1.5rem 2rem;
    margin: 1rem 0;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 1rem;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    animation: slideIn 0.3s ease;
}

.alert-success {
    background: linear-gradient(135deg, #c6f6d5, #9ae6b4);
    color: #22543d;
    border: 1px solid #68d391;
}

.alert-error {
    background: linear-gradient(135deg, #fed7d7, #fc8181);
    color: #742a2a;
    border: 1px solid #f56565;
}

.alert-close {
    margin-left: auto;
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: inherit;
    padding: 0 0.5rem;
}

@keyframes slideIn {
    from { transform: translateY(-20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}
`;

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#logoutBtn').forEach(btn => {
        btn.addEventListener('click', logout);
    });
    document.getElementById('closeModal')?.addEventListener('click', closeModal);
    document.getElementById('cancelBtn')?.addEventListener('click', closeModal);
    window.addEventListener('click', (e) => {
        const modal = document.getElementById('patientModal');
        if (e.target === modal) closeModal();
    });
    
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        patientForm.addEventListener('submit', savePatient);
    }
    
    document.querySelector('[data-modal="addPatient"]')?.addEventListener('click', () => openModal());
    
    document.getElementById('patientsPerPage')?.addEventListener('change', (e) => {
        patientsPerPage = parseInt(e.target.value);
        loadPatients(1);
    });
    
    document.getElementById('searchInput')?.addEventListener('input', debounce((e) => {
    }, 300));
});

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}